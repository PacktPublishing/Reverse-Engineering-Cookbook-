#include <jni.h>
#include <stdio.h>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_jniexample_MainActivity_stringFromJNI(JNIEnv* env, jobject /* this */) {
    return env->NewStringUTF("Hello from C++");
}

extern "C"
JNIEXPORT jint JNICALL
Java_com_example_jniexample_MainActivity_addTwoNumbers(JNIEnv *env, jobject obj, jint a, jint b) {
    return a + b;  // Simply add the two integers and return the sum
}

// Define a native function
jstring nativeRegisteredHello(JNIEnv* env, jobject obj) {
    return env->NewStringUTF("Hello from registered JNI!");
}

// Declare the native method array to register
static JNINativeMethod methods[] = {
        {"helloFromJNI", "()Ljava/lang/String;", (void *)nativeRegisteredHello}
};

// Use JNI_OnLoad to register native methods
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    JNIEnv* env;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        return -1;
    }

    // Get the Java class
    jclass clazz = env->FindClass("com/example/jniexample/MainActivity");
    if (clazz == NULL) {
        return -1;
    }

    // Register native methods
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) < 0) {
        return -1;
    }

    return JNI_VERSION_1_6;
}
