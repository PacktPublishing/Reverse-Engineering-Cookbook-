package com.example.jniexample

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.jniexample.ui.theme.JNIExampleTheme

class MainActivity : ComponentActivity() {
    // Load the native library
    init {
            System.loadLibrary("native-lib")
    }

    // Declare the native method
    external fun stringFromJNI(): String
    external fun addTwoNumbers(a: Int, b: Int): Int
    external fun helloFromJNI(): String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Call the native method and get the string from C++
        //val nativeString = stringFromJNI()
        val nativeString = helloFromJNI() 
        val result = addTwoNumbers(10, 20)

        enableEdgeToEdge()
        setContent {
            JNIExampleTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = nativeString, //name = "Android",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    JNIExampleTheme {
        Greeting("Android")
    }
}